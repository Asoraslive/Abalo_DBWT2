<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ab_TestData</title>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-light bg-light justify-content-center">
    <img src="<?php echo e(asset('img/abalo_logo.png')); ?>" alt="" width="auto" height="200" class="">

</nav>
        <?php if($testdatas ?? null): ?>
            <table class="table table-sm">

                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Ab_TestName</th>
                </tr>
                </thead>
                <tbody>
            <?php $__currentLoopData = $testdatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($testdata->id); ?></th>
                    <td><?php echo e($testdata->ab_testname); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        </tbody>
    </table>
    <div class="alert alert-danger">
        <strong>Fehler?</strong> Es ist keine Liste Vorhanden.
    </div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\Uni\DBWT2\abalo\resources\views/testdataview.blade.php ENDPATH**/ ?>