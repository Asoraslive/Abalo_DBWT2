<div class="modal fade cookieModal" id="cookieModal" tabindex="-1" role="dialog" aria-labelledby="cookieModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="cookieModalLabel">Cookie Information</h2>
            </div>
            <div class="modal-body">
                <h4>Cookie Policy</h4>
                <p>[Cookie Message Here]</p>
                <p>
                    <a href="" target="_blank">Klick hier um unsere Cookie Richtlinien zu sehen!</a>
                </p>
            </div>
            <div class="modal-footer">
                <button id="cookieModalConsent" type="button" class="btn btn-primary btn-lg btn-block" data-dismiss="modal" onclick="cookieConsent()">Akzeptieren</button>
            </div>
        </div>
    </div>
</div>


<script src="<?php echo e(asset('js/cookiecheck.js')); ?>"></script>
<?php /**PATH D:\Uni\DBWT2\abalo\resources\views/Templates/cookieModal.blade.php ENDPATH**/ ?>