<?php $__env->startSection('title','Articlecategory'); ?>

<?php $__env->startSection('content'); ?>
    <form method="GET" action="<?php echo e(route('categories.show')); ?>" class="d-flex justify-content-center">
        <input id="search-text" name="search" class="form-control" type="search" placeholder="Suche nach Artikel" aria-label="Search" style="width: 50vw">
        <button class="btn btn-outline-primary" type="submit">Suchen</button>
    </form>


    <?php if($categories): ?>
        <table class="table" style="margin:20px 5vw 20px 5vw;width: 90vw">
            <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Name</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($category->id); ?></th>
                    <td><?php echo e($category->ab_name); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('more_script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Templates/base_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Uni\DBWT2\Abalo_DBWT2\abalo\resources\views/Random_assignments/articlecategories.blade.php ENDPATH**/ ?>